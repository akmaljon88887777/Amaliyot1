import React from 'react'

function FiveCardText() {
    return (
       <div></div>
    )
}

export default FiveCardText