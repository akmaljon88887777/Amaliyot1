import React from 'react'

function Cardtext() {
    return (
        <div>
            <h4 className="color text-xl font-medium">App Features</h4><br />
            <h4 className="text-4xl font-bold text-[#262B47]">Awesome Faetures</h4><br /><br />
        </div>
    )
}

export default Cardtext