import React from 'react'

function Threecardtext() {
    return (
        <div className='mt-40'>
            <h4 className="color text-xl font-medium">How It Works</h4>
            <h1 className="text-4xl text-[#262B47] font-bold">3 Easy Steps</h1><br />
            {/* <div className="flex justify-center mb-7">
                <button style={{ borderTopLeftRadius: '30px', borderBottomLeftRadius: '30px' }} className="justify-center text-white flex items-center w-[118px] h-[48px] btnb">Monthly</button>
                <button style={{ borderBottomRightRadius: '30px', borderTopRightRadius: '30px', borderTop: '2px solid #517AE8', borderLeft: '2px solid #5D65EC', borderRight: '2px solid #6D4BF1', borderBottom: '2px solid #802CF8' }} className="justify-center text-white flex items-center w-[118px] h-[48px] color ">Yearly</button>
            </div><br /> */}
        </div>
    )
}

export default Threecardtext